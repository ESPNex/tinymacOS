# Sorgenti correnti 10.2.2

[Scarica ZIP verificato](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.2/tinymacOS-10.2.2-sources.zip)

SHA-256: `b031da43a39a1856933835a2ede75da7b54bac3034b5c46732f5c832f9a8176a`
