#!/usr/bin/env python3
"""Execute the real upstream usbkbd IRQ and LED control in the actual ISO.
USB-only virtual keyboard (i8042 off); no diagnostic guest UI or test decoder.
Whole original UHCI/EHCI/xHCI, selected per profile; not a full USB core port.
"""
from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,tempfile,time
q=Path(__file__).resolve().parent;home=q.parents[1];root=home/'tinymacOS';sys.path.insert(0,str(root/'tests'))
from retail_guest import Retail
from linux_message_observer import observe_message
from linux_dma_observer import observe_dma
from linux_uhci_observer import observe_uhci
from linux_ehci_observer import observe_ehci
from linux_xhci_observer import observe_xhci
fw,profile=sys.argv[1:];assert fw in ['uefi','bios'];assert profile in ['ehci-kbd','companion-kbd','xhci-hub-kbd']
base=Path(os.environ.get('TMC_LINUX_STAGE','/var/tmp/tmc-10.1.7/linux-hid-v12'));build=base/'build';iso=base/'tinymacOS-10.1.7-x86_64.iso'
w=Path(tempfile.mkdtemp(prefix=f'tmc-linux-kbd-{fw}-{profile}-',dir='/var/tmp'));ev=w/'evidence';ev.mkdir()
os.environ.update(TOOLROOT='/var/tmp/tmc/tools/root',OCR_ROOT='/var/tmp/tmc/tools/root',TMC_MEM='512',TMC_BUILD=str(build),TMC_TEST_INPUT=profile,TMC_TEST_FIRMWARE=fw,TMC_POINTER='mouse')
r={'passed':False,'firmware':fw,'profile':profile,'iso_sha256':hashlib.file_digest(iso.open('rb'),'sha256').hexdigest(),'work':str(w),'actual_upstream_boot_keyboard_driver':True,'linux_hcd_port':profile.startswith(('ehci','uhci','companion','xhci')),'linux_full_usb_core_port':False,'native_hcd_transport_adapter':not profile.startswith(('ehci','uhci','companion','xhci')),'native_class_enumeration_facade':True,'physical_hardware_tested':False}
fields=['probes','attached','completions','frames','rejected','disconnected','controls','control_errors','stale_controls']
try:
 symbols=subprocess.check_output(['nm',str(build/'kernel.debug')],text=True).splitlines()
 addr=int(next(s.split()[0] for s in symbols if s.endswith(' b tmc_linux_kbd_stats')),16)
 for name in ['usb_kbd_irq','usb_kbd_probe','usb_kbd_event','usb_kbd_led','usb_kbd_disconnect','tmc_lx_usbkbd_driver']:
  assert any(s.endswith(' '+name) for s in symbols),name
 tool='/var/tmp/tmc/tools/root';env={**os.environ,'PATH':tool+'/usr/bin:'+os.environ['PATH'],'LD_LIBRARY_PATH':tool+'/usr/lib/x86_64-linux-gnu'}
 subprocess.run(['xorriso','-osirrox','on','-indev',str(iso),'-extract','/System/Library/KernelCollections/KernelCache',str(w/'actual.cache')],env=env,check=True,capture_output=True)
 assert (w/'actual.cache').read_bytes()==(build/'KernelCache').read_bytes();r['actual_iso_kernel_equals_build']=True
 with Retail(iso,w,ev,'linux-usbkbd',live=True,launcher=root/'tools/run-input-qa.sh') as g:
  r['message_core']=observe_message(g,symbols,w);r['actual_upstream_message_control_functions_executed']=True
  if profile.startswith(('ehci','uhci','companion','xhci')):r['dma_pool']=observe_dma(g,symbols,w);r['original_dma_pool_in_native_controller_executed']=True
  if profile.startswith(('uhci','companion')):r['whole_original_uhci_runtime']=observe_uhci(g,symbols,w)
  if profile.startswith('xhci'):
   r['whole_original_xhci_runtime']=observe_xhci(g,symbols,w)
   r['linux_controller_hcd_port']=True;r['native_hcd_transport_adapter']=False;r['native_class_enumeration_facade']=True
  if profile.startswith('ehci'):
   r['whole_original_ehci_runtime']=observe_ehci(g,symbols,w)
   r['linux_controller_hcd_port']=True;r['native_hcd_transport_adapter']=False;r['native_class_enumeration_facade']=True
  r['usb']=g.hmp('info usb');assert 'USB Keyboard' in r['usb']
  def counters():
   p=w/'kbd-stats.bin';g.req('pmemsave',val=addr,size=8*len(fields),filename=str(p));return dict(zip(fields,struct.unpack('<9Q',p.read_bytes())))
  def urb_counters():
   address=int(next(s.split()[0] for s in symbols if s.endswith(' b tmc_linux_urb_counters')),16)
   p=w/'urb-counters.bin';g.req('pmemsave',val=address,size=48,filename=str(p))
   return dict(zip(['submits','givebacks','unlinks','rejected','active','highwater'],struct.unpack('<6Q',p.read_bytes())))
  for name in ['usb_submit_urb','usb_init_urb','usb_get_urb','usb_kill_urb','usb_poison_anchored_urbs']:
   assert any(s.endswith(' '+name) for s in symbols),name
  for name in ['tmc_config_get_configuration','tmc_config_get_bos_descriptor','tmc_config_destroy_configuration']:
   assert any(s.endswith(' '+name) for s in symbols),name
  config_address=int(next(s.split()[0] for s in symbols if s.endswith(' b tmc_linux_config_counters')),16)
  p=w/'config-stats.bin';g.req('pmemsave',val=config_address,size=80,filename=str(p))
  r['config_core']=cfg=dict(zip(['opens','failures','descriptor_reads','configs','interfaces','endpoints','bos','notices','allocations','frees'],struct.unpack('<10Q',p.read_bytes())))
  assert cfg['opens']>=1 and cfg['descriptor_reads']>=2 and cfg['configs']>=1 and cfg['interfaces']>=1 and cfg['endpoints']>=1 and cfg['allocations']==cfg['frees'] and not cfg['failures'],cfg
  r['actual_upstream_core_config_file_executed']=True
  for name in ['hid_open_report','hid_register_report','hid_setup_resolution_multiplier','tmc_linux_hid_pointer_layout']:
   assert any(s.endswith(' '+name) for s in symbols),name
  hid_address=int(next(s.split()[0] for s in symbols if s.endswith(' b tmc_linux_hid_parser_counters')),16)
  p=w/'hid-parser-stats.bin';g.req('pmemsave',val=hid_address,size=72,filename=str(p))
  r['hid_parser']=hid=dict(zip(['opens','failures','closes','allocations','frees','live_bytes','peak_bytes','notices','busy'],struct.unpack('<9Q',p.read_bytes())))
  assert hid['opens']>=1 and hid['opens']==hid['closes'] and hid['allocations']==hid['frees'] and not hid['live_bytes'] and not hid['failures'] and not hid['busy'],hid
  r['actual_upstream_hid_parser_functions_executed']=True
  r['whole_linux_hid_core_or_hid_generic_driver']=False
  if 'hub' in profile:assert cfg['opens']>=3,cfg
  r['urb_core_before']=urb_counters()
  r['before']=before=counters();assert before['attached']==1,before
  g.enroll('PortLinux');g.key('f2');g.visible('Sessione locale')
  g.cmd('echo ITA-àèéìòù-£-€-@-#','ITA-àèéìòù-£-€-@-#')
  g.key('caps_lock');g.type('echo caps');g.key('caps_lock');g.key('ret');g.visible('ECHO')
  time.sleep(.5);r['after']=after=counters()
  assert after['completions']>before['completions']+50 and after['frames']==after['completions'],(before,after)
  assert after['controls']>=before['controls']+2 and not after['control_errors'] and not after['stale_controls'],(before,after)
  r['urb_core_after']=core=urb_counters();previous=r['urb_core_before']
  assert core['submits']>previous['submits'] and core['givebacks']>previous['givebacks'],(previous,core)
  assert core['submits']==core['givebacks']+core['active'] and core['active']>=1 and not core['rejected'],core
  r['actual_upstream_core_urb_file_executed']=True
  if profile.startswith('xhci'):
   r['whole_original_xhci_runtime_after']=observe_xhci(g,symbols,w)
   assert r['whole_original_xhci_runtime_after']['givebacks']>r['whole_original_xhci_runtime']['givebacks'],r['whole_original_xhci_runtime_after']
   r['linux_xhci_controller_executed']=True
  if profile.startswith('ehci'):
   r['whole_original_ehci_runtime_after']=observe_ehci(g,symbols,w)
   assert r['whole_original_ehci_runtime_after']['givebacks']>r['whole_original_ehci_runtime']['givebacks'],r['whole_original_ehci_runtime_after']
   r['linux_ehci_controller_executed']=True
  if profile.startswith(('uhci','companion')):
   r['whole_original_uhci_runtime_after']=observe_uhci(g,symbols,w)
   assert r['whole_original_uhci_runtime_after']['givebacks']>r['whole_original_uhci_runtime']['givebacks'],r['whole_original_uhci_runtime_after']
   r['linux_uhci_controller_executed']=True
  g.shot('linux-usbkbd-italian-leds');r['passed']=True
  r['checks']=['USB-only keyboard with virtual i8042 disabled','actual ISO KernelCache equals linked build','actual upstream probe/IRQ/event/LED/disconnect symbols','enrollment + F2 + rendered Italian Shift/AltGr/accent/euro command','Caps Lock on/off triggers two successful native EP0 LED controls']
 print('PASS actual Linux usbkbd IRQ + Italian input + LED controls',fw,profile,r['after'],flush=True)
finally:(q/f'linux-usbkbd-{fw}-{profile}.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
