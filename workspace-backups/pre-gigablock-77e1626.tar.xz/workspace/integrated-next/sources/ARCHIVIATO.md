# Copia storica archiviata

Il contenuto completo e conservato, byte per byte, in
`workspace/archives/legacy-maintenance-files.tar.xz`.

Indice e SHA-256: `workspace/archives/legacy-maintenance-files.json`.
Ripristino dalla radice /home/user:
```sh
tar -xJf workspace/archives/legacy-maintenance-files.tar.xz -C workspace
```
I sorgenti correnti rimangono in `tinymacOS/`.
