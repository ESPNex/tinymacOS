# tinymacOS 10.2.3 — CoW reale pubblicato

**Completato: implementazione → test finali → commit → merge su main → sostituzione della 10.2.3.** La release resta una pre-release sperimentale.

[Scarica ISO e sorgenti](https://github.com/ESPNex/tinymacOS/releases/tag/v10.2.3) · [Commit 09edd1e](https://github.com/ESPNex/tinymacOS/commit/09edd1ea626cc70ce82e8e47c42a1681a8905d56) · [Note e limiti](https://github.com/ESPNex/tinymacOS/blob/main/tinymacOS/docs/NOTE-10.2.3.md)

## Cosa è stato consegnato

- **CoW reale a settori**: inizialmente dati condivisi; un vecchio settore conservato una sola volta per gli snapshot che ne hanno bisogno; rilascio dello spazio quando scompare l’ultimo riferimento. Nessuna copia integrale a ogni creazione.
- Generazioni storiche leggibili dopo modifiche, cancellazioni, riavvii, ripristino di snapshot e backup/ripristino da Recovery. Journal/staging per le scritture interrotte e migrazione dei vecchi snapshot.
- Resize nativo **8–32 MiB** con capacità realmente variabile, ricollocazione di mappe/pool/backup, conservazione dei file e delle viste storiche.
- Utility Disco/Terminale/Recovery condivisi, FAT32 e motore NTFS nativo; avvio OpenCore automatico corretto e precedente BootOrder conservato.
- FileVault autentica e cifra anche i metadati e i vecchi blocchi CoW. Test BIOS ripetuto anche sul volume rilocato accanto a partizioni FAT32/NTFS/RAW conservate.

## Verifica conclusa

**29 gruppi di verifica PASS**, inclusi host normali e ASan/UBSan, motori filesystem/crypto reali, lettori indipendenti, ISO, installazione BIOS/UEFI, dual boot GPT/MBR, Recovery, FileVault e regressioni dell’interfaccia/input.

Il guest CoW ha conservato A e B mentre il file attivo era C: l’ispezione indipendente delle mappe reali ha trovato **2 settori storici**, anziché **12.576** di due copie complete.

ISO, sorgenti ZIP, checksum e manifesto di validazione sono stati caricati, **riscaricati e verificati con SHA-256** prima della sostituzione degli asset canonici. Main, branch di sviluppo e tag `v10.2.3` puntano al commit verificato. Le release 10.2.2 e 10.2.1 sono rimaste invariate; il vecchio tag della 10.2.3 è conservato in `archive/v10.2.3-before-cow-82ec7bc`.

## Download e identità

- [ISO 10.2.3](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.3/tinymacOS-10.2.3-x86_64.iso) — 226.498.560 byte
- [Sorgenti ZIP](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.3/tinymacOS-10.2.3-sources.zip)
- [VALIDAZIONE.json](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.3/VALIDAZIONE.json) · [SHA256SUMS.txt](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.3/SHA256SUMS.txt)

Commit:
```text
09edd1ea626cc70ce82e8e47c42a1681a8905d56
```
SHA-256 ISO:
```text
71d94c029deb8fa820d5f71dca8633d0ddcc85b784e55485a60343a7928d4dc0
```

Ricevute locali: `VALIDAZIONE.json`, `GITHUB-COW.json`, `STATUS.json`, `SHA256SUMS.txt` e `COMMIT.txt` nella stessa cartella.

## Limiti espliciti

Il formato è proprietario TMCBFS1/APFS-inspired, **non Apple APFS o Btrfs Linux**. Restano massimo 384 voci, 8 KiB per file e 8 snapshot; pool limitato e niente resize cifrato. Dopo il resize NTFS serve il controllo Windows. Migrazioni/resize e aggiornamenti delle tabelle non promettono rollback universale contro interruzioni.

**Backup esterno verificato obbligatorio.** Nessuna certificazione Windows reale, hardware fisico o audit crittografico indipendente; il precedente sistema delle fixture BIOS è un sentinel sintetico, non Windows.
