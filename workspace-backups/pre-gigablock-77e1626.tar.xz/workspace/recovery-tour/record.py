from pathlib import Path
import sys,os,time,threading,subprocess,struct,json,hashlib,shutil
sys.path.insert(0,'/home/user/tinymacOS/tests')
from retail_guest import Retail
from boot_recovery import RecoveryKey
import pixels,imageio_ffmpeg
from PIL import Image,ImageDraw,ImageFont
out=Path('/home/user/workspace/recovery-tour');work=Path('/var/tmp/tmc-recovery-video');work.mkdir(exist_ok=True);(work/'evidence').mkdir(exist_ok=True)
iso=Path('/var/tmp/tmc-10.2.1/tinymacOS-10.2.1-x86_64.iso')
assert hashlib.file_digest(iso.open('rb'),'sha256').hexdigest()=='aab46bb9b6ec1d6010731af6d34537f102b28ff0386170324064545907bb76ef'
(work/'target').mkdir(exist_ok=True)
shutil.copyfile('/var/tmp/tmc-bios-install-qa-gx056cs9/target/system.raw',work/'target/system.raw')
font=Path('/var/tmp/tmc-10.1.8-tinymacos-font/tinymacos-font.tfn').read_bytes();pixels.b=font;pixels.nf,pixels.ng=struct.unpack_from('<II',font,4);pixels.codes={c:j for j,c in enumerate(struct.unpack_from(f'<{pixels.ng}I',font,12))};pixels.start=12+pixels.ng*4;pixels.pix=pixels.start+pixels.nf*(pixels.ng*8+4);pixels.word.cache_clear()
os.environ.update(TOOLROOT='/var/tmp/tmc/tools/root',OCR_ROOT='/var/tmp/tmc/tools/root',TMC_MEM='512',TMC_POINTER='tablet',TMC_BUILD='/var/tmp/tmc-10.1.8/build')
class Recovery(RecoveryKey,Retail):
 recovery_text='Ripristina da una copia locale'
 def req(self,*a,**kw):
  with lock:return super().req(*a,**kw)
lock=threading.RLock();stop=threading.Event();chapters=[];caption='';frames=0;error=[]
ff=imageio_ffmpeg.get_ffmpeg_exe();video=out/'Recovery-10.2.1-tour.mp4'
f1=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',20);f2=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
def chapter(text,seconds=0):
 global caption
 caption=text;chapters.append({'seconds':round(frames/8,2),'title':text});print('CHAPTER',frames/8,text,flush=True)
 if seconds:time.sleep(seconds)
def capture(g):
 global frames
 try:
  start=time.monotonic()
  while not stop.is_set():
   p=work/'video-frame.ppm';g.req('screendump',filename=str(p))
   with Image.open(p) as source:im=source.convert('RGB')
   canvas=Image.new('RGB',(1280,880),(17,18,21));canvas.paste(im,(0,0));d=ImageDraw.Draw(canvas);d.text((24,813),caption,font=f1,fill='white');d.text((24,847),'REGISTRAZIONE REALE QEMU  |  10.2.1 / 30B12  |  Solo disco virtuale di prova  |  Nessun audio',font=f2,fill=(159,165,176));encoder.stdin.write(canvas.tobytes());frames+=1
   stop.wait(max(0,start+frames/8-time.monotonic()))
 except BaseException as e:error.append(repr(e));stop.set()
def menu(g,title,item=None):
 x,y=g.visible(title,box=(0,0,850,34));g.click(x+12,y+8);time.sleep(1.5)
 if item:
  x,y=g.visible(item,box=(0,34,900,250));g.click(x+20,y+8);time.sleep(.7)
def close(g):menu(g,'File','Chiudi finestra');time.sleep(.7)
def cancel(g):g.key('esc');time.sleep(.7)
def operation(g,title,home=None):
 chapter(title)
 if home is not None:g.click(550,270+86*home);time.sleep(.7);g.click(880,557)
 else:menu(g,'Utility',title)
 g.visible('Confermi l’operazione');time.sleep(3);g.click(820,470);g.visible('Operazione completata.',60);time.sleep(3);g.key('ret');time.sleep(1)
with Recovery(iso,work,work/'evidence','tour',disk='target',boot_disk=True) as g:
 encoder=subprocess.Popen([ff,'-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1280x880','-r','8','-i','-','-an','-c:v','libx264','-preset','ultrafast','-crf','23','-pix_fmt','yuv420p','-movflags','+faststart',str(video)],stdin=subprocess.PIPE,stderr=(work/'ffmpeg.log').open('wb'))
 thread=threading.Thread(target=capture,args=(g,),daemon=True);thread.start()
 try:
  chapter('Recovery nativa: avviata dal disco virtuale, senza ISO collegata',5)
  for i,label in enumerate(['Ripristina da una copia locale','Reinstalla tinymacOS','Utility Disco']):
   chapter('Home: '+label,0);g.click(550,270+86*i);time.sleep(2)
  chapter('Menu Apple: disco di avvio, riavvio e spegnimento');g.click(23,16);time.sleep(4);cancel(g)
  chapter('Menu Recupero: informazioni e versione');menu(g,'Recupero tinymacOS','Info sul Recupero');g.visible('Versione 10.2.1');time.sleep(4);g.key('ret')
  chapter('Menu File: Chiudi è disabilitato quando non ci sono app');menu(g,'File');time.sleep(3);cancel(g)
  chapter('Menu Modifica: Copia e Incolla sono disabilitati nei client Recovery');menu(g,'Modifica');time.sleep(3);cancel(g)
  chapter('Menu Utility: tutti gli strumenti di manutenzione');menu(g,'Utility');time.sleep(4);cancel(g)
  chapter('Menu Finestra: accesso alle app anche senza Dock');menu(g,'Finestra');time.sleep(3);cancel(g)
  chapter('Menu Aiuto: informazioni sul Recupero');menu(g,'Aiuto','Info sul Recupero');time.sleep(3);g.key('ret')
  chapter('Disco di avvio: conferma di riavvio nel firmware (annullata)');menu(g,'Utility','Disco di avvio');time.sleep(4);cancel(g)
  operation(g,'Crea una copia locale')
  operation(g,'Ripristina: esecuzione reale sulla copia del disco di prova',home=0)
  operation(g,'Reinstalla: esecuzione reale sul disco di prova',home=1)
  chapter('Inizializza dati: mostro la conferma, poi annullo');menu(g,'Utility','Inizializza i dati utente');g.visible('I dati verranno eliminati.');time.sleep(4);cancel(g)
  chapter('Utility Disco: finestra nativa scura e opaca');g.click(550,442);g.click(880,557);g.visible('Disco interno');time.sleep(3)
  chapter('Utility Disco: volumi e partizioni del disco virtuale')
  for _ in range(4):g.key('down');time.sleep(1.7)
  for _ in range(4):g.key('up')
  chapter('SOS: controllo e riparazione del disco virtuale');g.key('s');g.visible('Esegui SOS');time.sleep(3);g.key('ret');time.sleep(5)
  # The app remains visible; inspect remaining maintenance actions without a reboot.
  chapter('Utility Disco: copia locale e strumenti di manutenzione');g.key('b');time.sleep(3);cancel(g)
  chapter('Utility Disco: opzione Recupero (nessun riavvio eseguito)');g.key('r');time.sleep(3);cancel(g)
  chapter('Utility Disco: disponibilità snapshot in questa sessione Recovery');g.key('n');time.sleep(3);cancel(g)
  close(g)
  chapter('Terminale nativo: comandi eseguiti nella sessione Recovery');menu(g,'Utility','Terminale');g.visible('Sessione locale');time.sleep(2)
  for cmd in ['sw_vers','pwd','ls /','csrutil status']:
   chapter('Terminale: '+cmd);g.cmd(cmd);time.sleep(2.5)
  chapter('Terminale: file reale nella home RAM isolata');g.cmd('echo Recovery-demo > /Users/User/Documents/demo.txt');g.cmd('cat /Users/User/Documents/demo.txt','Recovery-demo');time.sleep(3)
  chapter('Due app aperte: Utility Disco sopra Terminale');menu(g,'Utility','Utility Disco');g.visible('Disco interno');time.sleep(3)
  chapter('Menu Finestra: minimizzazione senza Dock');menu(g,'Finestra','Riduci a icona');time.sleep(3)
  chapter('Menu Finestra: ripristino di Utility Disco');menu(g,'Finestra','Utility Disco');g.visible('Disco interno');time.sleep(3);close(g);close(g)
  chapter('Tastiera: F10, freccia giù e Invio aprono Terminale');g.key('f10');time.sleep(2);g.key('down');time.sleep(1);g.key('ret');g.visible('Sessione locale');time.sleep(2);close(g)
  chapter('Riavvio: conferma annullabile, nessun riavvio eseguito');g.click(23,16);x,y=g.visible('Riavvia',box=(0,34,350,200));g.click(x+20,y+8);g.visible('Riavviare il computer?');time.sleep(4);cancel(g)
  chapter('Spegnimento: conferma annullabile');g.click(23,16);x,y=g.visible('Spegni',box=(0,34,350,200));g.click(x+20,y+8);g.visible('Spegnere il computer?');time.sleep(4);cancel(g)
  chapter('Fine esplorazione — Recovery scura, opaca, stesso font del desktop',5)
 finally:
  stop.set();thread.join(15);encoder.stdin.close();assert encoder.wait(timeout=30)==0
  (out/'capitoli.json').write_text(json.dumps(chapters,indent=2,ensure_ascii=False));(out/'CAPITOLI.txt').write_text('\n'.join(f"{int(c['seconds'])//60:02}:{int(c['seconds'])%60:02}  {c['title']}" for c in chapters)+'\n')
  (out/'registrazione.json').write_text(json.dumps({'iso_sha256':hashlib.file_digest(iso.open('rb'),'sha256').hexdigest(),'frames':frames,'fps':8,'duration_seconds':frames/8,'screen':'unmodified 1280x800 framebuffer plus separate caption band','disk':'disposable copy of QA virtual disk','capture_errors':error},indent=2))
 assert not error,error
print('DONE',video,frames/8,flush=True)
