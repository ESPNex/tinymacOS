# Sorgenti 10.2.2 aggiornata

[Scarica lo ZIP verificato](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.2/tinymacOS-10.2.2-sources.zip)

SHA-256: `201c6ae8b610015031b51e6215dfa3249b5495583f60dbfdb59d9d03ef8d41a1`
