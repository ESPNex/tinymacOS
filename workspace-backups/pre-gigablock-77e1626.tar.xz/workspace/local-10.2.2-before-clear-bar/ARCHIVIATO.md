# Pubblicazione precedente della stessa 10.2.2

Sostituita dalla variante senza Indietro in FileVault e con barra desktop trasparente. Consegna corrente: `../local-10.2.2/`.
