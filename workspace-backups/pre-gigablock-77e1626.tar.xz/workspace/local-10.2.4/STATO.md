# tinymacOS 10.2.4 / 30B15 — pubblicata

**Regressione finale: 34 gruppi PASS**, tutti sulla stessa ISO.

- Desktop live: **Installa tinymacOS Tramontana**.
- Recovery: **Reinstalla tinymacOS Tramontana**. Stesso eseguibile del desktop, wizard reale e conferma obbligatoria.
- Reinstallazione: intera partizione dati invariata; sistema riscritto uguale alla copia locale sigillata.
- Recovery: nessuna barra residua, sei avvii BIOS/UEFI × 1/2/4 CPU.
- Dischi fino a 1 TiB: host GPT/MBR 1 TB/1 TiB e QEMU/AHCI, installazione ad alto LBA, avvii BIOS/UEFI, Recovery e sentinelle conservate.
- CoW, resize FAT32/NTFS/nativo, FileVault normale e rilocato, input USB, menu/Finder/materiali, avvio misto GPT/MBR: PASS.

Commit `1a4ca9af4c4e7bb42cc819e7f931da34f6a4af69`, main aggiornato con fast-forward e nuovo tag `v10.2.4`.

[Release e download](https://github.com/ESPNex/tinymacOS/releases/tag/v10.2.4)

Quattro asset caricati e riscaricati indipendentemente con verifica SHA-256: ISO, sorgenti ZIP, SHA256SUMS.txt, VALIDAZIONE.json. Le release 10.2.3, 10.2.2 e 10.2.1 sono rimaste invariate.

Dettagli in `REGRESSIONE.md`, `VALIDAZIONE.json`, `GITHUB.json`, `SHA256SUMS.txt`. Nessuna certificazione hardware fisico/Windows reale o audit crittografico indipendente. Volume dati nativo ancora 8–32 MiB: il limite 1 TiB riguarda il disco. Backup esterno verificato obbligatorio.
