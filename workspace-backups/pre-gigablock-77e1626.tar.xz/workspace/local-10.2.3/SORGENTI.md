# Sorgenti 10.2.3 / 30B14

[ZIP verificato](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.3/tinymacOS-10.2.3-sources.zip)

Commit: `82ec7bc198991c9d03a4dcb628d995caee35c5b7`

SHA-256: `3e0e8b629a216576adaefdafe4e655773249f1a6e84556d68f2d12f74bc095d3`
