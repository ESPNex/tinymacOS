# Pulizia workspace e screenshot

## Risultato
- Prima: 125,860,869 byte, 3656 file.
- Dopo pulizia, prima delle nuove schermate: 111,013,232 byte.
- Dopo aggiunta galleria e PNG: 118,021,007 byte, 3148 file (prima di questo resoconto).
- Circa 415.8 MB recuperati sul disco durante la pulizia, prima di aggiungere i nuovi screenshot.

## Conservato
Sorgenti attuali, ultima ISO e suo ZIP sorgenti, font forniti, ricevute release, file caricati e backup privati. SHA-256 dell'ultima ISO e del suo ZIP sorgenti ricontrollati dopo la pulizia: invariati. Nessun push o upload.

## Archiviato senza perdita
519 file di vecchie copie dei sorgenti e prove di manutenzione (2.4.1, 2.4.2, 2.4.3, integrated-next). Ogni file e stato confrontato byte per byte tramite SHA-256 con l'archivio prima di rimuovere la copia espansa.

- Archivio: `archives/legacy-maintenance-files.tar.xz`
- Indice, hash e lista degli intermedi rimossi: `archives/legacy-maintenance-files.json`
- Nelle cartelle originali rimane `ARCHIVIATO.md` con le istruzioni.

Ripristino dalla radice `/home/user`:
```sh
tar -xJf workspace/archives/legacy-maintenance-files.tar.xz -C workspace
```

## Eliminato
Solo oggetti/intermedi di tre vecchie build controller e due ISO native intermedie, gia superate dalle ISO finali BIOS/UEFI conservate. La lista completa e nell'indice JSON. Nessuna ISO finale consegnata e stata eliminata.

## Schermate
`workspace/screenshots-10.1.8/GALLERIA.html`: cinque schermate reali a 1280×800 con anteprime WebP lossless incorporate. `screenshot-tinymacOS-10.1.8-PNG.zip` contiene gli originali PNG non modificati e i checksum. Desktop, Info e Recovery appena acquisiti; menu chiaro/scuro dalle prove della medesima ISO.

Le acquisizioni QEMU non certificano l'hardware fisico ASRock.
