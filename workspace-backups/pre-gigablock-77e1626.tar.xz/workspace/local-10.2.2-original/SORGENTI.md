# Sorgenti 10.2.2

[Scarica lo ZIP verificato](https://github.com/ESPNex/tinymacOS/releases/download/v10.2.2/tinymacOS-10.2.2-sources.zip)

SHA-256: `b65e007a51565878e5c88035cc0f51828df1760845a86173d4c05757153b3020`

Il pacchetto completo rimane anche in `/var/tmp/tmc-10.2.2/` durante questa sessione.
