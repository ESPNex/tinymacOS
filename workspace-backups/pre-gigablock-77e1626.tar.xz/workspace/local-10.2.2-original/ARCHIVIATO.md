# Prima pubblicazione 10.2.2

Evidenza storica, sostituita nella stessa release dalla versione con FileVault integrato in Impostazioni. La consegna corrente è in `../local-10.2.2/`.
