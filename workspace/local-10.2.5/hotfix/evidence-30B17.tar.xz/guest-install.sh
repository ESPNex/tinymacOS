#!/bin/bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/var/tmp/tmc-python-release TOOLROOT=/var/tmp/tmc-tools TMC_BUILD=/var/tmp/tmc-1025-hotfix/build TMC_QA_DIR=/var/tmp/tmc-1025-hotfix/qa TMC_STAGE_ISO=/var/tmp/tmc-1025-hotfix/release/tinymacOS-10.2.5-x86_64.iso TMC_FONT=/home/user/tinymacOS/assets/type.tfn OCR_ROOT=/var/tmp/tmc-tools
python3 tinymacOS/tests/fs2_install_guest.py > /var/tmp/tmc-1025-hotfix/fs2-guest.log 2>&1
TMC_TRANSFER_POINTER=mouse python3 tinymacOS/tests/finder_transfers_guest.py > /var/tmp/tmc-1025-hotfix/transfers-guest.log 2>&1
