from pathlib import Path
import os,subprocess,json,time
r=Path('/home/user');out=Path('/var/tmp/tmc-1025-hotfix');env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/var/tmp/tmc-python-release','TOOLROOT':'/var/tmp/tmc-tools','TMC_BUILD':str(out/'build'),'TMC_QA_DIR':str(out/'qa'),'TMC_STAGE_ISO':str(out/'release/tinymacOS-10.2.5-x86_64.iso'),'TMC_FONT':str(r/'tinymacOS/assets/type.tfn'),'OCR_ROOT':'/var/tmp/tmc-tools'}
cases=[('native4k-install','native4k_install_guest.py',[],{}),('native4k-convert','fs2_convert_guest.py',[],{'TMC_CONVERT_4KN':'1'}),('fs2-convert','fs2_convert_guest.py',[],{}),('nvme-helper','nvme_helper_guest.py',['--fs2-installer'],{}),('external-import','fs2_external_import_guest.py',[],{}),('encrypted-install-reset','encrypted_install_reset_guest.py',[],{}),('fs2-backup-ui','fs2_backup_ui_guest.py',[],{}),('fs2-reset','fs2_reset_guest.py',[],{})]
results=[]
for name,script,args,extra in cases:
 start=time.monotonic()
 with (out/(name+'-fresh.log')).open('w') as log:
  try:p=subprocess.run(['python3',str(r/'tinymacOS/tests'/script),*args],env={**env,**extra},stdout=log,stderr=subprocess.STDOUT,timeout=1500);code=p.returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'name':name,'exit_code':code,'seconds':round(time.monotonic()-start,1)})
 (out/'guest-rest-results.json').write_text(json.dumps({'passed':all(x['exit_code']==0 for x in results),'complete':len(results)==len(cases),'cases':results},indent=2)+'\n');print(name,code,flush=True)
 if code:raise SystemExit(code)
