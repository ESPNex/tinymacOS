from pathlib import Path
import os,subprocess,json,hashlib,urllib.parse
base=Path('/var/tmp/tmc-30B18');root=Path('/home/user');out=base/'release';env={**os.environ,'GH_CONFIG_DIR':'/var/tmp/tmc-github-auth','GODEBUG':'http2client=0'};gh='/var/tmp/tmc-github-cli/gh';repo='repos/ESPNex/tinymacOS';git=['git','--git-dir=/var/tmp/tmc-github-git/tinymacOS.git','--work-tree=/home/user'];tag='v10.2.5-pre-release'
def api(path,method='GET',extra=()):return json.loads(subprocess.check_output([gh,'api',path,'--method',method,*extra],env=env,text=True))
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
proof=json.loads((root/'workspace/local-10.2.5/hotfix/verification-30B18.json').read_text());assert proof['passed'] and proof['all_required_gates_closed'] and proof['no_physical_hardware_certification_claim']
commit=(base/'release-commit.txt').read_text().strip();assert subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()==commit
assert not subprocess.check_output(git+['status','--porcelain','--untracked-files=no'],text=True).strip(),'Commit all sources/proofs before publication'
old=json.loads((base/'release-before.json').read_text());current=api(repo+'/releases/tags/'+tag);assert current['id']==old['id'] and not current.get('immutable')
before={x['name']:x for x in old['assets']};now={x['name']:x for x in current['assets']};assert set(now)==set(before)
for name,a in before.items():assert now[name]['id']==a['id'] and now[name].get('digest')==a.get('digest'),name
names=['SHA256SUMS','tinymacOS-10.2.5-sorgenti.zip','tinymacOS-10.2.5-x86_64.iso','VALIDAZIONE-10.2.5.md','VERIFICA-FINALE-10.2.5.tar.gz']
for name in names:assert (out/name).is_file()
helper='tinymacOS-10.2.5-NVMe-boot-helper.img';assert 'sha256:'+digest(out/helper)==before[helper]['digest']
assert digest(out/'tinymacOS-10.2.5-x86_64.iso')==proof['final_iso']['sha256']
pending=[]
for name in names:
 path=out/name;temporary=name+'.pending-30B18';url='https://uploads.github.com/'+repo+f"/releases/{old['id']}/assets?name="+urllib.parse.quote(temporary)
 result=api(url,'POST',['-H','Content-Type: application/octet-stream','--input',str(path)])
 assert result['name']==temporary and result['size']==path.stat().st_size and result['digest']=='sha256:'+digest(path),name
 pending.append({'name':name,'new_id':result['id'],'old_id':before[name]['id'],'sha256':digest(path),'bytes':path.stat().st_size})
 (base/'pending-upload-receipt.json').write_text(json.dumps({'release_commit':commit,'assets':pending},indent=2)+'\n');print('UPLOADED AND SERVER-HASH-VERIFIED',name,flush=True)
# Keep old public payloads until ALL new uploads are present and hash-verified.
for item in pending:
 subprocess.run([gh,'api',repo+f"/releases/assets/{item['old_id']}",'--method','DELETE'],env=env,check=True,capture_output=True)
 result=api(repo+f"/releases/assets/{item['new_id']}",'PATCH',['-f','name='+item['name']]);assert result['name']==item['name']
 print('REPLACED',item['name'],flush=True)
# Explicit, compare-and-swap replacement of this classified tag ONLY.
old_tag=next(line.split()[0] for line in (base/'tags-before.txt').read_text().splitlines() if line.split()[1]=='refs/tags/'+tag)
subprocess.run(git+['-c','credential.helper=!/var/tmp/tmc-github-cli/gh auth git-credential','push','--force-with-lease=refs/tags/'+tag+':'+old_tag,'origin',commit+':refs/tags/'+tag],env=env,check=True)
body=(out/'VALIDAZIONE-10.2.5.md').read_text();api(repo+f"/releases/{old['id']}",'PATCH',['-f','name='+old['name'],'-f','body='+body])
final=api(repo+'/releases/tags/'+tag);assets=final['assets'];assert len([a for a in assets if a['name'].endswith('.iso')])==1 and len(assets)==len(before)
assert {a['name'] for a in assets}==set(before)
for a in assets:assert a['digest']=='sha256:'+digest(out/a['name']),a['name']
(base/'release-after.json').write_text(json.dumps(final,indent=2)+'\n');print('REPUBLISHED',final['html_url'],'build 30B18; original title preserved, existing classified tag updated, exactly one ISO')
