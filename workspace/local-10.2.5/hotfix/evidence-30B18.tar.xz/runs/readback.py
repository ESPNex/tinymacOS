from pathlib import Path
import urllib.request,hashlib,json,subprocess,os
b=Path('/var/tmp/tmc-30B18');r=json.loads((b/'release-after.json').read_text());results=[]
for a in r['assets']:
 u=a['browser_download_url']+'?verify30B18=20261118';h=hashlib.sha256();size=0
 with urllib.request.urlopen(u,timeout=90) as response:
  while data:=response.read(1024*1024):h.update(data);size+=len(data)
 assert size==a['size'] and 'sha256:'+h.hexdigest()==a['digest'],a['name'];results.append({'name':a['name'],'bytes':size,'sha256':h.hexdigest(),'public_download_readback':True});print('READBACK PASS',a['name'],flush=True)
git=['git','--git-dir=/var/tmp/tmc-github-git/tinymacOS.git','--work-tree=/home/user'];env={**os.environ,'GH_CONFIG_DIR':'/var/tmp/tmc-github-auth','GODEBUG':'http2client=0'}
text=subprocess.check_output(git+['ls-remote','--tags','origin'],env=env,text=True);before=dict(line.split()[::-1] for line in (b/'tags-before.txt').read_text().splitlines());after=dict(line.split()[::-1] for line in text.splitlines());assert set(before)==set(after)
changed=[k for k in before if before[k]!=after[k]];assert changed==['refs/tags/v10.2.5-pre-release'];assert after[changed[0]]==(b/'release-commit.txt').read_text().strip()
p={'passed':True,'build':'30B18','release_url':r['html_url'],'release_id_unchanged':True,'one_ISO':True,'assets':results,'tags_preserved':len(after),'only_tag_changed':changed[0],'source_commit':after[changed[0]],'title':r['name'],'no_Safari_or_physical_hardware_certification_claim':True}
Path('/home/user/workspace/local-10.2.5/hotfix/publication-readback-30B18.json').write_text(json.dumps(p,indent=2)+'\n');print('ALL SIX PUBLIC PAYLOADS AND TAG INVENTORY VERIFIED')
