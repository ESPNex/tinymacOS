from pathlib import Path
import subprocess,os,json,time
from concurrent.futures import ThreadPoolExecutor
r=Path('/home/user');out=Path('/var/tmp/tmc-30B18');env={**os.environ,'TMC_BUILD':str(out/'build'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':'/var/tmp/tmc-python-release','TOOLROOT':'/var/tmp/tmc-tools'}
scripts=['test-hotfix-contract.py','test-windows-gaps.sh','test-input-maintenance.sh','test-legacy-input.sh','test-linux-usbhid.sh','test-finder-transfers.sh','test-installer-flow.sh','test-partitions.sh','test-large-disks.sh','test-fs2-install.sh','test-fs2-convert.sh','test-native4k-install.sh','test-nvme.sh']
def run(name):
 start=time.monotonic();cmd=['python3' if name.endswith('.py') else 'bash',str(r/'tinymacOS/tests'/name)]
 try:
  p=subprocess.run(cmd,env=env,text=True,capture_output=True,timeout=900);record={'name':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,2),'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired:record={'name':name,'exit_code':124,'seconds':round(time.monotonic()-start,2),'stdout':'','stderr':'timeout, NOT PASS'}
 (out/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(name,record['exit_code'],flush=True);return record
with ThreadPoolExecutor(max_workers=1) as pool:results=list(pool.map(run,scripts))
(out/'host-results.json').write_text(json.dumps({'passed':all(x['exit_code']==0 for x in results),'cases':results},indent=2)+'\n')
raise SystemExit(not all(x['exit_code']==0 for x in results))
