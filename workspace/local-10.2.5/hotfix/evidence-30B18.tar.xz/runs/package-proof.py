from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path('/home/user');base=Path('/var/tmp/tmc-30B18');qa=base/'qa';out=root/'workspace/local-10.2.5/hotfix';pack=base/'evidence-package';assert not pack.exists();pack.mkdir()
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def load(p):return json.loads(p.read_text())
iso=base/'release/tinymacOS-10.2.5-x86_64.iso';iso_sha=sha(iso)
host=load(base/'host-results.json');runtime=load(base/'runtime-host.json');guest=load(base/'guest-rest-results.json');media=load(qa/'final-media-audit.json')
for a,n in [(host,13),(runtime,18),(guest,14)]:
 assert a['passed'] and len(a['cases'])==n and all(c['exit_code']==0 for c in a['cases'])
assert guest['complete'] and media['passed'] and media['iso_sha256']==iso_sha and media['build']=='30B18'
assert media['all_three_catalogs_byte_equal_to_fresh_native_build'] and media['no_external_font_fallback']
assert set(media['panic_font']['found_in'])=={'live.cache','disk.cache','recovery.elf'}
assert load(base/'fontmetrics-host.json')['passed'] and load(base/'font-negative-lock.json')['passed']
assert 'PASS deterministic TFN2' in (base/'font-host.log').read_text()
assert 'PASS fixed-cell pixel decoder' in (base/'mono-decoder-host.log').read_text()
receipts=['release-optical-guest-result.json','fs2-install-guest-result.json','finder-transfers-guest-result.json','native4k-install-guest-result.json','native4k-convert-guest-result.json','fs2-convert-guest-result.json','fs2-nvme-helper-result.json','fs2-external-import-guest-result.json','encrypted-install-reset-guest-result.json','fs2-backup-ui-result.json','fs2-reset-guest-result.json','hotfix-windows-guest.json']
for name in receipts:
 a=load(qa/name);assert a['passed'],name
 if 'iso_sha256' in a:assert a['iso_sha256']==iso_sha,name
 else:assert a['actual_fs2_installer_fixture'] and a['installed_kernel_sha256']==media['kernels']['live.cache'],name
for kind in ('bios','uefi'):
 p=base/f'pointer-{kind}/evidence/pointer.json';a=load(p);assert a['passed'] and a['firmware']==kind and a['iso_sha256']==iso_sha
 shutil.copy2(p,pack/f'pointer-{kind}.json')
source=load(base/'source-inputs.json')['sha256']
for name,expected in source.items():assert sha(root/'tinymacOS'/name)==expected,name
# Retain the original launcher/setup failure, not recast as a product pass.
for f in list(base.glob('*.json'))+list(qa.glob('*.json'))+list(base.glob('*.log'))+list(base.glob('*.py')):
 if f.name=='release-before.json':continue
 dest=pack/('qa' if f.parent==qa else 'runs')/f.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(f,dest)
# Include the rejected candidate evidence, but never its ISO payload.
for f in (base/'rejected-build-without-fs2').rglob('*'):
 if f.is_file() and f.suffix in ('.json','.log'):
  dest=pack/'rejected-build-without-fs2'/f.relative_to(base/'rejected-build-without-fs2');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
for f in [root/'tinymacOS/assets/type.json',root/'tinymacOS/assets/interface-font-lock.json',root/'workspace/local-10.2.5/hotfix/mono-font-update.json']:shutil.copy2(f,pack/f.name)
frames=[]
for name in ['release-optical-guest-result.json','finder-transfers-guest-result.json','hotfix-windows-guest.json','encrypted-install-reset-guest-result.json']:
 work=Path(load(qa/name)['work']);ev=work/'evidence';selected=[]
 for pattern in ['release-optical-uefi.png','release-optical-bios.png','finder-transfer-context-drag-terminal-passed.png','finder-transfers-persistent-after-reboot.png','healthy-installer-gap.png','degraded-installer-gap.png','encrypted-reset-new-account-persistent.png']:
  selected.extend(ev.glob(pattern))
 for f in selected:
  dest=pack/f.name;shutil.copy2(f,dest);frames.append({'original':str(f),'name':f.name,'sha256':sha(f),'unmodified':True})
assert len(frames)>=6
(pack/'frame-provenance.json').write_text(json.dumps(frames,indent=2)+'\n')
(pack/'NOTES.txt').write_text('30B18 full fresh rebuild. All current guest suites use the final dual ISO or its hash-bound installed fixture/kernel. 13 OS host + 18 runtime host cases passed. Font deterministic source-open allowlist, actual C fontmetrics normal and ASan/UBSan, and previous-font override rejection passed. 14 guest suites complete. Media audit checks exact TFN2 in all three namespaces and exact panic bitmap in both live/install KernelCache and extracted Recovery ELF. Initial optical attempt passed UEFI but BIOS launcher refused before QEMU because a globally supplied NVMe helper conflicts with SATA; corrected QA environment scopes helper to NVMe case only. Original failure log/result retained, complete fresh optical rerun passed. No OS assertion weakened. First legacy-FS candidate was rejected by real installer superblock assertion; production build.sh pinned FS2, rebuilt entire ISO and repeated all 14 suites. Rejected candidate receipts and hashes preserved, not counted as passes. New Mono exposed old secret-key OCR side-bearing assumption; QA-only fixed-cell decoder added with min correlation 0.98 and uniqueness margin 0.005; synthetic lower/uppercase light/dark and corruption rejection passed. Native4k conversion resumed after unacknowledged preparation on same final ISO; credentials/hash/reboot/deactivation assertions retained. No secrets logged. These are emulated/synthetic tests, not physical mouse/Windows certification, not Safari/WebKit acceptance. Prior 30B17 results not counted.\n')
manifest={str(f.relative_to(pack)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(pack.rglob('*')) if f.is_file()};(pack/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
for dest,mode in [(out/'evidence-30B18.tar.xz','w:xz'),(base/'release/VERIFICA-FINALE-10.2.5.tar.gz','w:gz')]:
 with tarfile.open(dest,mode) as t:
  for f in sorted(pack.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(pack)))
 with tarfile.open(dest) as t:
  for n,expected in manifest.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==expected['sha256']
proof={'passed':True,'all_required_gates_closed':True,'version':'10.2.5','build':'30B18','fresh_OS_host_cases':13,'fresh_runtime_host_cases':18,'fresh_guest_suites':14,'font_host_reproduction':True,'fontmetrics_normal_and_sanitized':True,'previous_font_override_rejected':True,'current_final_media_audit':True,'panic_bitmap_verified_in_all_three_kernels':True,'all_final_guest_media_final_dual_ISO':True,'native_and_dual_catalogs_byte_equal':True,'single_fresh_invocation':False,'QA_environment_first_attempt_and_rerun_retained':True,'legacy_FS_candidate_rejected_and_fully_rebuilt':True,'no_physical_hardware_certification_claim':True,'Safari_full_WebKit_included':False,'source_inputs_rechecked':len(source),'final_iso':{'filename':iso.name,'bytes':iso.stat().st_size,'sha256':iso_sha},'production_font_sha256':load(root/'tinymacOS/assets/interface-font-lock.json')['sha256'],'evidence_archive':{'file':'evidence-30B18.tar.xz','bytes':(out/'evidence-30B18.tar.xz').stat().st_size,'sha256':sha(out/'evidence-30B18.tar.xz'),'files_including_manifest':len(manifest)+1,'all_member_hashes_verified':True},'release_replacement_not_yet_performed':True}
(out/'verification-30B18.json').write_text(json.dumps(proof,indent=2)+'\n');print('PASS all required fresh 30B18 gates, evidence members verified',len(manifest)+1)
